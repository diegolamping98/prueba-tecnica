import { Button, TableCell, TableRow } from '@mui/material';
import React from 'react'
import { useNavigate } from 'react-router-dom';
import { deleteEmployee, getListEmployees } from '../services/localstore';

export const EmployeeItem = ({employee, setEmployees}) => {



    const { id,nombre,apellido,email,cedula,inss,fecNac} = employee;
    const  removeEmployee = () => {
        deleteEmployee(id);
        setEmployees(getListEmployees());
      }

 const navigate = useNavigate();

  return (
    <TableRow
    key={nombre}
    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
  >
    <TableCell component="th" scope="row"> {nombre}</TableCell>
    <TableCell align="left">{apellido}</TableCell>
    <TableCell align="center">{email}</TableCell>
    <TableCell align="left">{cedula}</TableCell>
    <TableCell align="left">{inss}</TableCell>
    <TableCell align="center">{fecNac}</TableCell>


    <div>
    <Button 
      variant="contained" color="primary"
      onClick={() => navigate(`/${id}/editar`)}>
      Editar 
    </Button>

     <Button 
         variant="contained" color="error"
         onClick={() => removeEmployee()}>
         Eliminar 
         
      </Button>
</div>

  </TableRow>
  )
}
