import { FormGroup, Grid, TextField , Button} from '@mui/material'
import { useNavigate, useParams } from 'react-router-dom'
import useForm from '../hooks/useForm'
import { addEmployee, editEmployee, getEmployeeById } from '../services/localstore'
import React, { useEffect, useState } from 'react'
import uuid4 from 'uuid4'
import {AuthLayout} from '../layout/AuthLayout'

export const EmpoloyeeForm = () => {
  
  
const { inputValues, handleInputChange, reserForm,setForm } = useForm({
    nombre: '',
    apellido: '',
    email: '',
    cedula: '',
    inss: '',
    fecNac: '',
  });
   
  const [showAlert, setshowAlert] = useState(false);
      const { id } = useParams();
      const navigate = useNavigate();
      const onNavigateBack = () => {
        navigate(-1);
      }
    
      useEffect(() => {
        if (id) {
            const employee = getEmployeeById(id);
            setForm(employee);
        }
    }, [id]);
  
 
    const handleSubmit = (e) => {
      console.log(inputValues)
      e.preventDefault();
      id ? editEmployee(id, inputValues) : addEmployee({ id: uuid4(), ...inputValues });
      reserForm();
      
      setshowAlert(true);
      setTimeout(() => {
          setshowAlert(false);
      }, 2000);
      
  };
    
  
  
    return (

    <AuthLayout>
      <form onSubmit={handleSubmit}>

<h1 className="my-3 text-center">{id ? "Editar" : "Agregar"} Empleado</h1>
<Grid >
        <TextField
          label="Nombre" 
          type="text" 
          placeholder='Nombres' 
          fullWidth
          name="nombre"
          value={inputValues.nombre}
          onChange={handleInputChange}
          
        />
      </Grid>


      <Grid item xs={ 12 } sx={{ mt: 2 }}>
        <TextField 
          label="Apellido" 
          type="text" 
          placeholder='Apellidos' 
          fullWidth
          name="apellido"
          value={inputValues.apellido}
          onChange={handleInputChange}
          
        />
      </Grid>

      <Grid item xs={ 12 } sx={{ mt: 2 }}>
        <TextField 
          label="Correo" 
          type="email" 
          placeholder='correo@google.com' 
          fullWidth
          name="email"
          
          value={inputValues.email}
          onChange={handleInputChange}
          
        />
      </Grid>

      <Grid item xs={ 12 } sx={{ mt: 2 }}>
        <TextField 
          label="Cedula" 
          type="text" 
          placeholder='000-00000-0000Y' 
          fullWidth
          name="cedula"
          value={inputValues.cedula}
          onChange={handleInputChange}
         
          
        />
      </Grid>


      <Grid item xs={ 12 } sx={{ mt: 2 }}>
        <TextField 
          label="Numero INSS" 
          type="text" 
          fullWidth
          name="inss"
          value={inputValues.inss}
          onChange={handleInputChange}
          
          
        />
      </Grid>

      <Grid item xs={ 12 } sx={{ mt: 2 }}>
        <TextField 
        
          type="date" 
          fullWidth
          name="fecNac"
          value={inputValues.fecNac}
          onChange={handleInputChange}
          
        />

      <Button
        className="btn btn-warning"
        onClick={onNavigateBack}
      >
        Regresar
      </Button>

       <Button 
          type="submit" 
          className="btn btn-outline-primary btn-block"
          
          
          >{id ? "Editar" : "Agregar"} Empleado</Button>


     {
            showAlert && (
                <div className="px-5">
                    <div className="alert alert-success">
                        <strong>Bien Hecho</strong> {id ? "Editar" : "Agregar Nuevo"} Empleado.
                    </div>
                </div>
            )

        }
      </Grid>

     

</form>


    </AuthLayout>
    

        

  )
}
