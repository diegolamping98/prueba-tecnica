import { useState } from "react"
import { useParams } from "react-router-dom";
import uuid4 from "uuid4";


import { addEmployee, editEmployee } from '../services/localstore'

export const useForm = (initialState = {}) => {
const { id } = useParams();
const [inputValues, setinputValues] = useState(initialState);



  
const reserForm = () => {
    setinputValues(initialState);
}



const setForm = (newValues) => {
    setinputValues(newValues);
  };

  const handleInputChange = ({ target }) => {
    setinputValues({
      ...inputValues,
      [target.name]: target.value,
    });
  };



return {
    inputValues,
    handleInputChange,
    reserForm,
    setForm,
    editEmployee
   
}
}

export default useForm;
