import { Route, Routes } from "react-router-dom"
import { EmployeeList } from "./components/EmployeeList"
import { EmpoloyeeForm } from "./components/EmpoloyeeForm"
import { NavBar } from "./components/NavBar"


export const EmployedApp = () => {
  return (


<div>
    <   NavBar/>


    <Routes>
          <Route path ="/" element ={<EmployeeList/>} />
          <Route path ="/nuevo" element ={<EmpoloyeeForm/>} />
          <Route path ="/:id/editar" element ={<EmpoloyeeForm/>} />

    </Routes>
</div>
    

     
  )
}
